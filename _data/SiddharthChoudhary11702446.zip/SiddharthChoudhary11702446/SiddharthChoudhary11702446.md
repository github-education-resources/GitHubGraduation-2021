---
name: Siddharth Choudhary   
institution: Lovely Professional University
quote: I will never let fear of failure stop me doing things I care about.
github_user: siddharthzs
---